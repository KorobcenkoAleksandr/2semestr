import psycopg2
from psycopg2 import Error

def delete_in_bulk(records):
    try:
        connection = psycopg2.connect(
            user="postgres",
            password="1111",
            host="127.0.0.1",
            port="5432",
            database="postgres_db"
        )
        cursor = connection.cursor()
        cursor.executemany("DELETE FROM mobile WHERE id = %s", records)
        connection.commit()
        print(cursor.rowcount, "Записи удалены")
    except (Exception, Error) as error:
        print("Ошибка при работе с PostgreSQL", error)
    finally:
        if connection:
            cursor.close()
            connection.close()
            print("Соединение с PostgreSQL закрыто")

delete_in_bulk([(5,), (4,), (3,)])