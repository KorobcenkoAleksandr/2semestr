import psycopg2
from psycopg2 import Error

def delete_data(mobile_id):
    try:
        connection = psycopg2.connect(
            user="postgres",
            password="1111",
            host="127.0.0.1",
            port="5432",
            database="postgres_db"
        )
        cursor = connection.cursor()
        
        cursor.execute("DELETE FROM mobile WHERE id = %s", (mobile_id,))
        connection.commit()
        print(cursor.rowcount, "Запись успешно удалена")

    except (Exception, Error) as error:
        print("Ошибка при работе с PostgreSQL", error)
    finally:
        if connection:
            cursor.close()
            connection.close()
            print("Соединение с PostgreSQL закрыто")

delete_data(4)
delete_data(5)