import psycopg2
from psycopg2 import Error

def update_in_bulk(records):
    try:
        connection = psycopg2.connect(
            user="postgres",
            password="1111",
            host="127.0.0.1",
            port="5432",
            database="postgres_db"
        )
        cursor = connection.cursor()
        
        cursor.executemany(
            "UPDATE mobile SET price = %s WHERE id = %s",
            records
        )
        connection.commit()
        print(cursor.rowcount, "Записи обновлены")

    except (Exception, Error) as error:
        print("Ошибка при работе с PostgreSQL", error)
    finally:
        if connection:
            cursor.close()
            connection.close()
            print("Соединение с PostgreSQL закрыто")

update_in_bulk([(750, 4), (950, 5)])